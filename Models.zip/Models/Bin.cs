﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HackathonProject.Models
{
    public class Bin
    {
        //primary key
        public int ID { get; set; }
        //fk to storage locations
        public int storageLocationID { get; set; }
        //weight of the container that holds the items
        public double containerWeight { get; set; }
        // sku of the item
        public int SKU { get; set; }
        //description / name of the item
        public string itemName { get; set; }
        //weight per single unit in the item
        public double unitWeight { get; set; }
        //the calculated item count 
        public int itemCount { get; set; }
        // the minmum # of items before triggering an alert to the home page
        public int minimumInventory { get; set; }
    }
}